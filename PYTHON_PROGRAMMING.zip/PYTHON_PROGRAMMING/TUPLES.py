numbers=(5,1,2,3,2)
print(numbers[0])
print(numbers.count(2))
print(numbers.index(2))