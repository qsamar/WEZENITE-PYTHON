a = 2.9
print(round(a))
print(abs(-2.9))

import math

print(math.ceil(2.9))
print(math.floor(2.9))
