course = 'python for beginners'
print(course)
print(course[0])
print(course[0:3])
name2 = 'Jennifer'
print(name2[1:-1])

first = 'John'
last = 'smith'
message = first + '[' + last + '] is a coder'
print(message)


print(len(course))
print(course.upper())
print(course.lower())
print(course.find('p'))
print(course.replace('beginners' , 'absolute beginners'))
print('python' in course)