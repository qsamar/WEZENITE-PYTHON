coordinates=(1,2,3)
x,y,z=coordinates
print(x)
print(y)
print(z)