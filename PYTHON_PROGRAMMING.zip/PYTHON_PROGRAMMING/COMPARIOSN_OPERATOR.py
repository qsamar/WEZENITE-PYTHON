temperature = 35
if temperature > 30:
    print("It is hot day")
else:
    print("It is not a hot day")


nam = "J"
if len(nam) < 3:
    print("Name must be at least 3 characters.")
elif len(nam) > 50:
    print("Name must be maximum of 50 characters.")
else:
    print("Name looks good!")
