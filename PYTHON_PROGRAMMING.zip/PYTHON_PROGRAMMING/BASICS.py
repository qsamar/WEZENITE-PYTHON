print("Hello world")
print('o--')
print('!!!!')
print('*' * 10)

price = 10
rating = 4.9
name1 = 'Mosh'
is_pblished = True
print(price)

full_name = 'John smith'
age = 20
is_new = True
#receiving inputs
name = input('What is your name?')
favorite_color = input('What is your favorite color?')
print(name + 'likes' + favorite_color)