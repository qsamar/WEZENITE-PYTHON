import converters
from converters import kg_to_lbs
kg_to_lbs(100)
print(converters.kg_to_lbs(70))

#finding the max
from utils import find_max
numbers = [10,3,6,2]
max = find_max(numbers)
print(max)
