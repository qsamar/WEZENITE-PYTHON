birth_year = input('Birth year:')
print(type(birth_year))
age = 2019 - int(birth_year)
print(type(age))
print(age)

weight_lbs = input('Weight(lbs):')
weight_kg = int(weight_lbs) * 0.45
print(weight_kg)